module pp_to_squit(
input             i_clk_50,
input			  i_squitter_en,
input      [19:0] i_pulse_rate,
output reg [27:0] squitDelay 
);


wire [47:0] divideOut;
reg [19:0] prevPulseRate=0;
reg divide_valid=0;

always @(posedge i_clk_50)
begin
	if(i_pulse_rate != prevPulseRate)
	begin
		divide_valid <= 1;
	end
	else
		divide_valid <= 0;
		
	prevPulseRate <= i_pulse_rate;
end

div_gen_0 findPulseRate (
  .aclk(i_clk_50),                                     
  .s_axis_divisor_tvalid(divide_valid),    
  .s_axis_divisor_tdata(i_pulse_rate),    
  .s_axis_dividend_tvalid(divide_valid), 
  .s_axis_dividend_tdata(50000000),   
  .m_axis_dout_tvalid(squitDelayValid),         
  .m_axis_dout_tdata(divideOut)  
);

always @(posedge i_clk_50)
begin
	if(~i_squitter_en)
		squitDelay <= 0;
	else if(squitDelayValid)
		squitDelay <= divideOut[43:16];
end


endmodule